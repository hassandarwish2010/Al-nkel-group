<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdn.ckeditor.com/4.4.3/full/ckeditor.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1');
    CKEDITOR.replace('editor2');
  });
</script>
<?php $__env->stopSection(); ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="en_name"><?php echo e(__('lang.en_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="en_name" placeholder="<?php echo e(__('lang.en_name')); ?>" name="en_name" value="<?php if(old('en_name') != null): ?><?php echo e(old('en_name')); ?><?php elseif(isset($job)): ?><?php echo e($job->en_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('en_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('en_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="ar_name"><?php echo e(__('lang.ar_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="ar_name" placeholder="<?php echo e(__('lang.ar_name')); ?>" name="ar_name" value="<?php if(old('ar_name') != null): ?><?php echo e(old('ar_name')); ?><?php elseif(isset($job)): ?><?php echo e($job->ar_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('ar_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('ar_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="en_details"><?php echo e(__('lang.en_details')); ?> *</label>
                <textarea id="editor1" name="en_details" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.en_details')); ?>"><?php if(old('en_details') != null): ?><?php echo e(old('en_details')); ?><?php elseif(isset($job->en_details)): ?><?php echo e($job->en_details); ?><?php endif; ?></textarea>
                <?php if($errors->has('en_details')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('en_details')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="ar_details"><?php echo e(__('lang.ar_details')); ?> *</label>
                <textarea id="editor2" name="ar_details" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.ar_details')); ?>"><?php if(old('ar_details') != null): ?><?php echo e(old('ar_details')); ?><?php elseif(isset($job->ar_details)): ?><?php echo e($job->ar_details); ?><?php endif; ?></textarea>
                <?php if($errors->has('ar_details')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('ar_details')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
