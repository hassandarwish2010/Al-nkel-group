<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
	<title>franchise Json API Documentations</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">



    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
	<div class="container-fluid">
		<div class="page-header">
		<h1>Franchise Json API Documentations <small></small></h1>
	</div>
	<div class="row">
		<div class="col-md-2 col-sm-3">
			<div class="panel panel-primary">
      <div class="panel-heading">Sections</div>
      <div class="panel-body">
      	<ul class="nav nav-pills nav-stacked">
  <li class="active"><a data-toggle="pill" href="#home">Base URLS</a></li>
<!--   <li><a data-toggle="pill" href="#menu3">Conventions</a></li>
 -->  <li><a data-toggle="pill" href="#menu1">URLS</a></li>
<!--   <li><a data-toggle="pill" href="#menu2">Driver App</a></li>
 --></ul>

      </div>
    </div>
		</div>
		<div class="col-md-10 col-sm-9">


      	<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
    <div class="panel panel-default">
  <div class="panel-heading">Basic URLS</div>
  <div class="panel-body">
  	<table class="table">
  		<thead>
  	<tr>
  	<th><strong>Server : </strong></th>

  	</tr>
  </thead>
  </table>
  </div>
</div>
  </div>
  <div id="menu1" class="tab-pane fade">
    <div class="panel panel-default">
  <div class="panel-heading">App URLs</div>
  <div class="panel-body">
    <div class="alert alert-warning">

</div>
  	<table class="table">
  		<thead>
  			<th>Method</th>
  			<th>Relative Path</th>
  			<th>Description</th>
  			<th>Parameters</th>
  			<th>Result</th>
  		</thead>
  		<tbody>
  			<tr>
  				<td><strong>Post : </strong></td>
  				<td>all-hotels</td>
  				<td>get all hotels</td>
  				<td>-</td>

  			</tr>
            <tr>
                <td><strong>Post : </strong></td>
                <td>get-one-hotel</td>
                <td>get details of this hotel</td>
                <td>id</td>
            </tr>
            <tr>
                <td><strong>Post : </strong></td>
                <td>cities</td>
                <td>get all cities</td>
                <td>-</td>
            </tr>
            <tr>
                <td><strong>Post : </strong></td>
                <td>city</td>
                <td>get details of this city</td>
                <td>id</td>
            </tr>
            <tr>
                <td><strong>Post : </strong></td>
                <td>rooms</td>
                <td>get all rooms</td>
                <td>-</td>
            </tr>

            <tr>
                <td><strong>Post : </strong></td>
                <td>room</td>
                <td>get details of this room</td>
                <td>id</td>
            </tr>
            <tr>
                <td><strong>Post : </strong></td>
                <td>airports</td>
                <td>get all airports</td>
                <td>-</td>
            </tr>

            <tr>
                <td><strong>Post : </strong></td>
                <td>airport</td>
                <td>get details of this airport</td>
                <td>id</td>
            </tr>


  		</tbody>
  </table>
  </div>
</div>
  </div>


  </div>

</div>
</div>
	</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
