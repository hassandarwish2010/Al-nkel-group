<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.ckeditor.com/4.4.3/full/ckeditor.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1');
    CKEDITOR.replace('editor2');
  });
</script>
<?php $__env->stopSection(); ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="en_title"><?php echo e(__('lang.en_title')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="en_title" placeholder="<?php echo e(__('lang.en_title')); ?>" name="en_title" value="<?php if(old('en_title') != null): ?><?php echo e(old('en_title')); ?><?php elseif(isset($banner)): ?><?php echo e($banner->en_title); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('en_title')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('en_title')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="ar_title"><?php echo e(__('lang.ar_title')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="ar_title" placeholder="<?php echo e(__('lang.ar_title')); ?>" name="ar_title" value="<?php if(old('ar_title') != null): ?><?php echo e(old('ar_title')); ?><?php elseif(isset($banner)): ?><?php echo e($banner->ar_title); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('ar_title')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('ar_title')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <label for="image"><?php echo e(__('lang.image')); ?> <?php if(isset($banner)): ?> <?php else: ?> * <?php endif; ?></label>
          <div class="input-group">
              <div class="input-group-addon"><i class="ti-gallery"></i></div>
              <input type="file" class="form-control" id="image" name="image">
          </div>
          <?php if(isset($banner)): ?>
            <img src="<?php echo e($banner->image); ?>" alt="<?php echo e($banner->en_title); ?>" class="thumb-image">
          <?php endif; ?>
          <div class="input-group">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="en_description"><?php echo e(__('lang.en_description')); ?> *</label>
                <textarea id="editor1" name="en_description" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.en_description')); ?>"><?php if(old('en_description') != null): ?><?php echo e(old('en_description')); ?><?php elseif(isset($banner->en_description)): ?><?php echo e($banner->en_description); ?><?php endif; ?></textarea>
                <?php if($errors->has('en_description')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('en_description')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="ar_description"><?php echo e(__('lang.ar_description')); ?> *</label>
                <textarea id="editor2" name="ar_description" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.ar_description')); ?>"><?php if(old('ar_description') != null): ?><?php echo e(old('ar_description')); ?><?php elseif(isset($banner->ar_description)): ?><?php echo e($banner->ar_description); ?><?php endif; ?></textarea>
                <?php if($errors->has('ar_description')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('ar_description')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
