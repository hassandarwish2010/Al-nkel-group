

<?php $__env->startSection('js'); ?>


<script src="https://cdn.ckeditor.com/4.4.3/full/ckeditor.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1');
    CKEDITOR.replace('editor2');
  });
</script>
<?php $__env->stopSection(); ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="en_name"><?php echo e(__('lang.en_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="en_name" placeholder="<?php echo e(__('lang.en_name')); ?>" name="en_name" value="<?php if(old('en_name') != null): ?><?php echo e(old('en_name')); ?><?php elseif(isset($travel)): ?><?php echo e($travel->en_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('en_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('en_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="ar_name"><?php echo e(__('lang.ar_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="ar_name" placeholder="<?php echo e(__('lang.ar_name')); ?>" name="ar_name" value="<?php if(old('ar_name') != null): ?><?php echo e(old('ar_name')); ?><?php elseif(isset($travel)): ?><?php echo e($travel->ar_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('ar_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('ar_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="from_date"><?php echo e(__('lang.from_date')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="date" class="form-control" id="from_date" placeholder="<?php echo e(__('lang.from_date')); ?>" name="from_date" value="<?php if(old('from_date') != null): ?><?php echo e(old('from_date')); ?><?php elseif(isset($travel)): ?><?php echo e($travel->from_date); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('from_date')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('from_date')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="to_date"><?php echo e(__('lang.to_date')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="date" class="form-control" id="to_date" placeholder="<?php echo e(__('lang.to_date')); ?>" name="to_date" value="<?php if(old('to_date') != null): ?><?php echo e(old('to_date')); ?><?php elseif(isset($travel)): ?><?php echo e($travel->to_date); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('to_date')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('to_date')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="from_country"><?php echo e(__('lang.from_country')); ?> *</label>
            <div class="input-group" style="width: 100%">
              <select class="js-example-basic-multiple-limit js-states form-control" name="from_country">
                  <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>" <?php if(isset($travel)): ?> <?php if($travel->from_country == $city->id): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> <?php if(old('from_country') == $city->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($city->ar_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('from_country')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('from_country')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="to_country"><?php echo e(__('lang.to_country')); ?> *</label>
            <div class="input-group" style="width: 100%">
              <select class="js-example-basic-multiple-limit js-states form-control" name="to_country">
                  <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>" <?php if(isset($travel)): ?> <?php if($travel->to_country == $city->id): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> <?php if(old('from_country') == $city->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($city->ar_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('to_country')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('to_country')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="type"><?php echo e(__('lang.period')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" class="form-control" id="period" placeholder="<?php echo e(__('lang.period')); ?>" name="period" value="<?php if(old('period') != null): ?><?php echo e(old('period')); ?><?php elseif(isset($travel)): ?><?php echo e($travel->period); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('period')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('period')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.price')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" step=".1" class="form-control" id="price" placeholder="<?php echo e(__('lang.price')); ?>" name="price" value="<?php if(old('price') != null): ?><?php echo e(old('price')); ?><?php elseif(isset($travel)): ?><?php echo e($travel->price); ?><?php endif; ?>" required="required" min="0">
            </div>
            <div class="input-group">
            <?php if($errors->has('price')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('price')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="description_en"><?php echo e(__('lang.description_en')); ?> *</label>
                <textarea id="editor1" name="description_en" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.description_en')); ?>"><?php if(old('description_en') != null): ?><?php echo e(old('description_en')); ?><?php elseif(isset($travel->description_en)): ?><?php echo e($travel->description_en); ?><?php endif; ?></textarea>
                <?php if($errors->has('description_en')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('description_en')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="details"><?php echo e(__('lang.description_ar')); ?> *</label>
                <textarea id="editor2" name="description_ar" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.description_ar')); ?>"><?php if(old('description_ar') != null): ?><?php echo e(old('description_ar')); ?><?php elseif(isset($travel->description_ar)): ?><?php echo e($travel->description_ar); ?><?php endif; ?></textarea>
                <?php if($errors->has('description_ar')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('description_ar')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="white-space">
      <div class="form-group">
          <label for="image"><?php echo e(__('lang.image')); ?> <?php if(isset($travel)): ?> <?php else: ?> * <?php endif; ?></label>
          <div class="input-group">
              <div class="input-group-addon"><i class="ti-gallery"></i></div>
              <input type="file" class="form-control" id="image" name="image">
          </div>
          <?php if(isset($travel)): ?>
            <img src="<?php echo e($travel->image); ?>" alt="<?php echo e($travel->name); ?>" class="thumb-image" style="width: 70px;height: 70px">
          <?php endif; ?>
          <div class="input-group">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
      </div>
    </div>
  </div>
</div>





<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
