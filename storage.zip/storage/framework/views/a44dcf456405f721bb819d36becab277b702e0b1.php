</div>
<!-- end main-content -->

<!-- Footer -->
<footer id="footer" class="footer pb-0" data-bg-img="<?php echo e(asset('public/web/template/images/footer-bg.png')); ?>" data-bg-color="#25272e">
  <div class="container pt-90 pb-60">
    <div class="row">
      <div class="col-sm-6 col-md-3">
        <div class="widget dark">
          <a href="<?php echo e(route('home', $lang)); ?>"><img alt="Medline" src="<?php echo e(asset('public/web/template/images/logo.png')); ?>"></a>
          <?php if($about_us_page != null): ?>
          <p class="font-12 mt-10 mb-10">
            <?php $about_us_details = $lang.'_details'?> <?php echo e($about_us_page->$about_us_details); ?>

          </p>
          <a class="btn btn-default btn-transparent btn-xs btn-flat mt-5" href="<?php echo e(route('about', ['lang' => $lang, 'permalink' => $about_us_page->permalink])); ?>"><?php echo e(__('lang.read_more')); ?></a>
          <?php endif; ?>
          <ul class="styled-icons icon-dark icon-theme-colored icon-circled icon-sm mt-20">
            <?php if(isset($setting->facebook) && $setting->facebook != null): ?>
              <li><a href="<?php echo e($setting->facebook); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <?php endif; ?>
            <?php if(isset($setting->twitter) && $setting->twitter != null): ?>
              <li><a href="<?php echo e($setting->twitter); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <?php endif; ?>
            <?php if(isset($setting->googleplus) && $setting->googleplus != null): ?>
              <li><a href="<?php echo e($setting->googleplus); ?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
            <?php endif; ?>
            <?php if(isset($setting->linkedin) && $setting->linkedin != null): ?>
              <li><a href="<?php echo e($setting->linkedin); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
      <div class="col-sm-6 col-md-3">
        <div class="widget dark">
          <h5 class="widget-title line-bottom-theme-colored-2"><?php echo e(__('lang.latest_products')); ?></h5>
          <div class="latest-posts">
            <?php $__empty_1 = true; $__currentLoopData = $latest_3_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="post media-post clearfix pb-0 mb-10">
              <a class="post-thumb" href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $product->permalink])); ?>"><img src="<?php echo e($product->image); ?>" alt="" class="footer-products"></a>
              <div class="post-right">
                <h5 class="post-title mt-0 mb-5"><a href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $product->permalink])); ?>"><?php $product_name = $lang.'_name'?> <?php echo e($product->$product_name); ?></a></h5>
                <p class="post-date mb-0 font-12"><?php echo e($product->created_at); ?></p>
              </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            there is no products until now !
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-3">
        <div class="widget dark">
          <h5 class="widget-title line-bottom-theme-colored-2"><?php echo e(__('lang.contact_us')); ?></h5>
          <form id="contact_form_landing" name="" class="quick-contact-form" action="<?php echo e(route('contact.save', $lang)); ?>" method="post">
            <div class="form-group">
              <input name="name" class="form-control" type="text" required="required" placeholder="<?php echo e(__('lang.name')); ?>">
              <div id="failed_contact_name" class="help-block"></div>
            </div>
            <div class="form-group">
              <input name="email" class="form-control" type="email" required="rqeuired" placeholder="<?php echo e(__('lang.email')); ?>">
              <div id="failed_contact_email" class="help-block"></div>
            </div>
            <div class="form-group">
              <textarea name="details" class="form-control" required="rqeuired" placeholder="<?php echo e(__('lang.enter_message')); ?>" rows="3"></textarea>
              <div id="failed_contact_details" class="help-block"></div>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-default btn-transparent btn-xs btn-flat mt-0" data-loading-text="Please wait..."><?php echo e(__('lang.send_message')); ?></button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-sm-6 col-md-3">
        <div class="widget dark">
          <h5 class="widget-title line-bottom-theme-colored-2"><?php echo e(__('lang.contact_info')); ?></h5>
          <div class="opening-hours">
            <ul class="list list-border">
              <?php if(isset($setting->address) && $setting->address != null): ?>
              <li class="clearfix"> <span><i class="fa fa-map-marker mr-5"></i> <?php echo e(__('lang.address')); ?> :</span>
                <div class="value pull-right"><?php echo e($setting->address); ?></div>
              </li>
              <?php endif; ?>
              <?php if(isset($setting->phone) && $setting->phone != null): ?>
              <li class="clearfix"> <span><i class="fa fa-phone mr-5"></i> <?php echo e(__('lang.phone')); ?> :</span>
                <div class="value pull-right d-ltr"> <?php echo e($setting->phone); ?> </div>
              </li>
              <?php endif; ?>
              <?php if(isset($setting->email) && $setting->email != null): ?>
              <li class="clearfix"> <span><i class="fa fa-envelope mr-5"></i> <?php echo e(__('lang.email')); ?> :</span>
                <div class="value pull-right"> <?php echo e($setting->email); ?> </div>
              </li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-theme-colored p-20">
    <div class="row text-center">
      <div class="col-md-12">
        <p class="text-white font-11 m-0"><?php echo e(__('lang.copyright')); ?> &copy;<?php echo e(date('Y')); ?>

          <a class="typical" href="http://td.com.eg" target="_blank">Typical design</a>
          <?php echo e(__('lang.right_reserved')); ?></p>
      </div>
    </div>
  </div>
</footer>
<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<?php echo $__env->make('web.partials.success_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('web.partials.failed_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
