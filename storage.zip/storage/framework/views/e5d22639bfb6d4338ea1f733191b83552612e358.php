<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="hotel"><?php echo e(__('lang.hotel')); ?> *</label>
            <div class="input-group" style="width: 100%">
              <select class="js-example-basic-multiple-limit js-states form-control" name="hotel_id">
                  <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($hotel->id); ?>" <?php if(isset($room)): ?> <?php if($room->hotel_id == $hotel->id): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> <?php if(old('hotel_id') == $hotel->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($hotel->ar_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('hotel_id')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('hotel_id')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.number')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" class="form-control" id="number" placeholder="<?php echo e(__('lang.number')); ?>" name="number" value="<?php if(old('number') != null): ?><?php echo e(old('number')); ?><?php elseif(isset($room)): ?><?php echo e($room->number); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('number')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('number')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="type"><?php echo e(__('lang.type')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="type" placeholder="<?php echo e(__('lang.type')); ?>" name="type" value="<?php if(old('type') != null): ?><?php echo e(old('type')); ?><?php elseif(isset($room)): ?><?php echo e($room->type); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('type')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('type')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.price')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" step=".1" class="form-control" id="price" placeholder="<?php echo e(__('lang.price')); ?>" name="price" value="<?php if(old('price') != null): ?><?php echo e(old('price')); ?><?php elseif(isset($room)): ?><?php echo e($room->price); ?><?php endif; ?>" required="required" min="0">
            </div>
            <div class="input-group">
            <?php if($errors->has('price')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('price')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="max_children"><?php echo e(__('lang.max_children')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" class="form-control" id="max_children" placeholder="<?php echo e(__('lang.max_children')); ?>" name="max_children" value="<?php if(old('max_children') != null): ?><?php echo e(old('max_children')); ?><?php elseif(isset($room)): ?><?php echo e($room->max_children); ?><?php endif; ?>" required="required" min="0">
            </div>
            <div class="input-group">
            <?php if($errors->has('max_children')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('max_children')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.max_adult')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number"  class="form-control" id="max_adult" placeholder="<?php echo e(__('lang.max_adult')); ?>" name="max_adult" value="<?php if(old('max_adult') != null): ?><?php echo e(old('max_adult')); ?><?php elseif(isset($room)): ?><?php echo e($room->max_adult); ?><?php endif; ?>" required="required" min="0">
            </div>
            <div class="input-group">
            <?php if($errors->has('max_adult')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('max_adult')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="max_baby"><?php echo e(__('lang.max_baby')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" class="form-control" id="max_baby" placeholder="<?php echo e(__('lang.max_baby')); ?>" name="max_baby" value="<?php if(old('max_baby') != null): ?><?php echo e(old('max_baby')); ?><?php elseif(isset($room)): ?><?php echo e($room->max_baby); ?><?php endif; ?>" required="required" min="0">
            </div>
            <div class="input-group">
            <?php if($errors->has('max_baby')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('max_baby')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.status')); ?> *</label>
            <div class="input-group" style="width: 100%">
              <select class="js-example-basic-multiple-limit js-states form-control" name="status">
                  <?php for($i=0;$i<2;$i++): ?>
                    <option value="<?php echo e($i); ?>" <?php if(isset($room)): ?> <?php if($room->status == $i): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> <?php if(old('status') == $i): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e(($i==0?'متاح':"غير متاح")); ?></option>
                  <?php endfor; ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('status')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('status')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>



<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <label style="height:16px;"></label>
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
