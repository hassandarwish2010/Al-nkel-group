<header class="main-header">
    <!-- Logo -->
    <a href="" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>sfar</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Asfar</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

     <?php echo $__env->make('layouts.dashbord.menue', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(url('public/design/adminlte')); ?>/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(auth()->user()->name); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->

      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span><?php echo e(auth()->user()->name); ?></span>
            <span class="pull-right-container">
            </span>
          </a>
          <ul class="treeview-menu">
              <li><a href="<?php echo e(route('admin.get.profile')); ?>"><i class="fa fa-user"></i> <?php echo e(__('lang.profile')); ?> </a></li>

                    <li>
                      <a href="javascript:void(0)"
                         onclick="event.preventDefault(); document.getElementById('side-bar-logout-form').submit();">
                         <i class="fa fa-power-off"></i>
                          <?php echo e(__('Logout')); ?>

                          <form id="side-bar-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo csrf_field(); ?>
                          </form>
                      </a>
                    </li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('admin.dashboard')); ?>">
              <i class="fa fa-users"></i> <span><?php echo e(__('lang.dashboard')); ?> </span> 
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('hotels.index')); ?>">
              <i class="fa fa-users"></i> <span><?php echo e(__('lang.hotels')); ?> </span> 
            </a>
         </li>

       
        </ul> 

        

        
    </section>
    <!-- /.sidebar -->
  </aside>