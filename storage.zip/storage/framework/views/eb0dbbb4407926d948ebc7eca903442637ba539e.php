<?php $__env->startSection('title', __('lang.product_images')); ?>

<?php echo $__env->make('admin/layouts/datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title"><?php echo e(__('lang.product_images')); ?></h4>
    </div>
    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('lang.dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('products.index')); ?>"><?php echo e(__('lang.products')); ?></a></li>
        <li class="active"><?php echo e(__('lang.product_images')); ?></li>
      </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<div class="row">
  <div class="col-12">
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>
  </div>
</div>
<div class="row">
  <div class="col-sm-12">
      <div class="white-box">
          <a class="box-title m-b-1 btn btn-info btn-rounded" href="<?php echo e(route('create.product.gallery', $product_id)); ?>"><?php echo e(__('lang.add_new')); ?></a>
          <div class="table-responsive">
              <table id="table" class="display nowrap" cellspacing="0" width="100%">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th><?php echo e(__('lang.image')); ?></th>
                          <th><?php echo e(__('lang.actions')); ?></th>
                      </tr>
                  </thead>
                  <tfoot>
                      <tr>
                        <th>#</th>
                        <th><?php echo e(__('lang.image')); ?></th>
                        <th><?php echo e(__('lang.actions')); ?></th>
                      </tr>
                  </tfoot>
                  <tbody>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td>
                            <img src="<?php echo e($image->image); ?>" alt="product image" class="thumb-image">
                          </td>
                          <td class="text-nowrap">
                              <a href="javascript:void(0)" class="delete_confirmation" data-toggle="modal" data-target="#myModal" data-action="<?php echo e(route('destroy.product.gallery', $image->id)); ?>">
                                 <i class="fa fa-close text-danger"></i>
                               </a>
                          </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
          </div>
      </div>
  </div>
</div>
<?php echo $__env->make('admin.partials.confirm_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>