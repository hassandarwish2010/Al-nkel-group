<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/admin/css/jquery-gmaps-latlon-picker.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="http://maps.googleapis.com/maps/api/js?sensor=false&key=AIzaSyA5HbN7RwGeBLCFVi8RmDDrOVysfZIs_Gk"></script>
<script src="<?php echo e(asset('public/admin/js/jquery-gmaps-latlon-picker.js')); ?>"></script>
<script>
  $(document).ready(function() {
    // Copy the init code from "jquery-gmaps-latlon-picker.js" and extend it here
    $(".gllpLatlonPicker").each(function() {
      $obj = $(document).gMapsLatLonPicker();

      $obj.params.strings.markerText = "Drag this Marker (example edit)";

      $obj.params.displayError = function(message) {
        console.log("MAPS ERROR: " + message); // instead of alert()
      };

      $obj.init( $(this) );
    });
  });
  $('input.gllpSearchField').keypress(function(e) {
    if(e.which == 13) {
        $('input.gllpSearchButton').click();
        console.log("pressed");
        return false;
    }
  });
</script>
<?php $__env->stopSection(); ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="phone"><?php echo e(__('lang.phone')); ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-mobile"></i></div>
                <input type="text" class="form-control" id="phone" placeholder="<?php echo e(__('lang.phone')); ?>" name="phone" value="<?php if(old('phone') != null): ?><?php echo e(old('phone')); ?><?php elseif(isset($setting)): ?><?php echo e($setting->phone); ?><?php endif; ?>">
            </div>
            <div class="input-group">
            <?php if($errors->has('phone')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('phone')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="email"><?php echo e(__('lang.email')); ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                <input type="text" class="form-control" id="email" placeholder="<?php echo e(__('lang.email')); ?>" name="email" value="<?php if(old('email') != null): ?><?php echo e(old('email')); ?><?php elseif(isset($setting)): ?><?php echo e($setting->email); ?><?php endif; ?>">
            </div>
            <div class="input-group">
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
      <div class="white-box">
        <div class="form-group">
            <label for="phone"><?php echo e(__('lang.address')); ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-map-marker"></i></div>
                <input type="text" class="form-control" id="address" placeholder="<?php echo e(__('lang.address')); ?>" name="address" value="<?php if(old('address') != null): ?><?php echo e(old('address')); ?><?php elseif(isset($setting)): ?><?php echo e($setting->address); ?><?php endif; ?>">
            </div>
            <div class="input-group">
            <?php if($errors->has('address')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('address')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="phone"><?php echo e(__('lang.facebook')); ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-facebook"></i></div>
                <input type="text" class="form-control" id="facebook" placeholder="<?php echo e(__('lang.facebook')); ?>" name="facebook" value="<?php if(old('facebook') != null): ?><?php echo e(old('facebook')); ?><?php elseif(isset($setting)): ?><?php echo e($setting->facebook); ?><?php endif; ?>">
            </div>
            <div class="input-group">
            <?php if($errors->has('facebook')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('facebook')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="googleplus"><?php echo e(__('lang.googleplus')); ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-google-plus"></i></div>
                <input type="text" class="form-control" id="googleplus" placeholder="<?php echo e(__('lang.googleplus')); ?>" name="googleplus" value="<?php if(old('googleplus') != null): ?><?php echo e(old('googleplus')); ?><?php elseif(isset($setting)): ?><?php echo e($setting->googleplus); ?><?php endif; ?>">
            </div>
            <div class="input-group">
            <?php if($errors->has('googleplus')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('googleplus')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="phone"><?php echo e(__('lang.twitter')); ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-twitter"></i></div>
                <input type="text" class="form-control" id="twitter" placeholder="<?php echo e(__('lang.twitter')); ?>" name="twitter" value="<?php if(old('twitter') != null): ?><?php echo e(old('twitter')); ?><?php elseif(isset($setting)): ?><?php echo e($setting->twitter); ?><?php endif; ?>">
            </div>
            <div class="input-group">
            <?php if($errors->has('twitter')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('twitter')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="linkedin"><?php echo e(__('lang.linkedin')); ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-linkedin"></i></div>
                <input type="text" class="form-control" id="linkedin" placeholder="<?php echo e(__('lang.linkedin')); ?>" name="linkedin" value="<?php if(old('linkedin') != null): ?><?php echo e(old('linkedin')); ?><?php elseif(isset($setting)): ?><?php echo e($setting->linkedin); ?><?php endif; ?>">
            </div>
            <div class="input-group">
            <?php if($errors->has('linkedin')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('linkedin')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
      <div class="white-box">
        <div class="form-group">
            <label for="location"><?php echo e(__('lang.location')); ?></label>
            <div class="input-group">
                <fieldset class="gllpLatlonPicker" style="width:100%;">
                  <div>
                    <input type="text" class="gllpSearchField" style="color:black; width:70%; float:left" placeholder="Search for address">
                    <input type="button" class="gllpSearchButton btn btn-primary" value="Search for address" style="padding: 2px 15px; vertical-align: none;float:right;margin-right:1%">
                  </div>
                  <div class="gllpMap" style="margin-top:50px;">Google Maps</div>
                  <input type="hidden" class="gllpLatitude" value="<?php if(old('lat') != null): ?><?php echo e(old('lat')); ?><?php elseif(isset($setting->lat)): ?><?php echo e($setting->lat); ?><?php else: ?> 30.04 <?php endif; ?>" name="lat"/>
                  <input type="hidden" class="gllpLongitude" value="<?php if(old('lon') != null): ?><?php echo e(old('lon')); ?><?php elseif(isset($setting->lon)): ?><?php echo e($setting->lon); ?><?php else: ?> 31.24 <?php endif; ?>" name="lon"/>
                  <input type="hidden" class="gllpZoom" value="18"/>
                </fieldset>
            </div>
            <div class="input-group">
            <?php if($errors->has('lat')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('lat')); ?></strong>
                </span>
            <?php endif; ?>

            <?php if($errors->has('lon')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('lon')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
