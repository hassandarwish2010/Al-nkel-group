<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="from_en"><?php echo e(__('lang.from_en')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="from_en" placeholder="<?php echo e(__('lang.from_en')); ?>" name="from_en" value="<?php if(old('from_en') != null): ?><?php echo e(old('from_en')); ?><?php elseif(isset($transport)): ?><?php echo e($transport->from_en); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('from_en')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('from_en')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.from_ar')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="from_ar" placeholder="<?php echo e(__('lang.from_ar')); ?>" name="from_ar" value="<?php if(old('from_ar') != null): ?><?php echo e(old('from_ar')); ?><?php elseif(isset($transport)): ?><?php echo e($transport->from_ar); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('from_ar')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('from_ar')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="to_en"><?php echo e(__('lang.to_en')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="to_en" placeholder="<?php echo e(__('lang.to_en')); ?>" name="to_en" value="<?php if(old('to_en') != null): ?><?php echo e(old('to_en')); ?><?php elseif(isset($transport)): ?><?php echo e($transport->to_en); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('to_en')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('to_en')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="to_ar"><?php echo e(__('lang.to_ar')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="to_ar" placeholder="<?php echo e(__('lang.to_ar')); ?>" name="to_ar" value="<?php if(old('to_ar') != null): ?><?php echo e(old('to_ar')); ?><?php elseif(isset($transport)): ?><?php echo e($transport->to_ar); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('to_ar')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('to_ar')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>
<div class="row">
  <div class="col col-md-12">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.price')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" step=".1" class="form-control" id="price" placeholder="<?php echo e(__('lang.price')); ?>" name="price" value="<?php if(old('price') != null): ?><?php echo e(old('price')); ?><?php elseif(isset($transport)): ?><?php echo e($transport->price); ?><?php endif; ?>" required="required" min="0">
            </div>
            <div class="input-group">
            <?php if($errors->has('price')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('price')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <label style="height:16px;"></label>
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
