<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('lang.name')); ?>" name="name" value="<?php if(old('name') != null): ?><?php echo e(old('name')); ?><?php elseif(isset($user)): ?><?php echo e($user->name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="email"><?php echo e(__('lang.email')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                <input type="email" class="form-control" id="email" placeholder="<?php echo e(__('lang.email')); ?>" name="email" value="<?php if(old('email') != null): ?><?php echo e(old('email')); ?><?php elseif(isset($user)): ?><?php echo e($user->email); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="password"><?php echo e(__('lang.password')); ?> <?php if(! isset($user)): ?> * <?php endif; ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-ban"></i></div>
                <input type="password" class="form-control" id="password" placeholder="<?php echo e(__('lang.password')); ?>" name="password">
            </div>
            <div class="input-group">
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
    <div class="white-box">
      <label style="height:17px;"></label>
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
