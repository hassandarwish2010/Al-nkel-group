

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="number"><?php echo e(__('lang.number_times')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-money"></i></div>
                <input type="number" class="form-control" id="number" placeholder="<?php echo e(__('lang.number_times')); ?>" name="number" value="" min="1" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('number')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('number')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
   <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.balance')); ?> *</label>
            <div class="input-group" style="width: 100%">
              <select class="js-example-basic-multiple-limit js-states form-control" name="card_id">
                    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="text-center" value="<?php echo e($card->id); ?>"><?php echo e($card->balance); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('card_id')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('card_id')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>





<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
