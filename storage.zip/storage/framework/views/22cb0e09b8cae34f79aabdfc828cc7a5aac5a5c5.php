<?php
  $jobs_name = $lang.'_name';
  $jobs_details = $lang.'_details';
?>

<?php $__env->startSection('title', __('lang.jobs')); ?>
<?php $__env->startSection('description', 'Medical - Health & Medical HTML Template'); ?>
<?php $__env->startSection('keywords', 'clinic, dental, doctor, health, hospital, medical, medical theme, medicine, therapy'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.js"></script>
<script>
$(document).ready(function() {
  $(".fancybox").fancybox();
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg1.jpg')); ?>">
  <div class="container pt-60 pb-60">
    <!-- Section Content -->
    <div class="section-content">
      <div class="row">
        <div class="col-md-12 xs-text-center">
          <h3 class="title text-white"><?php echo e(__('lang.jobs')); ?></h3>
          <ol class="breadcrumb mt-10 white">
            <li><a class="text-white" href="<?php echo e(route('home', $lang)); ?>"><?php echo e(__('lang.home_page')); ?></a></li>
            <li class="active text-theme-colored"><?php echo e(__('lang.jobs')); ?></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Section: Job Content -->
<section>
  <div class="container pb-0">
    <div class="row text-center">
      <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-sm-4">
        <div class="icon-box iconbox-border iconbox-theme-colored p-40">
          <a href="<?php echo e(route('job', ['lang' => $lang, 'job_id' => $job->id])); ?>" class="icon icon-gray icon-bordered icon-border-effect effect-flat">
            <i class="pe-7s-users"></i>
          </a>
          <h5 class="icon-box-title"><?php echo e($job->$jobs_name); ?></h5>
          <p class="text-gray"><?php echo e($job->$jobs_details); ?></p>
          <a class="btn btn-dark btn-sm mt-15" href="<?php echo e(route('job', ['lang' => $lang, 'job_id' => $job->id])); ?>"><?php echo e(__('lang.read_more')); ?></a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-xs-12" style="margin-bottom:50px;">
          <?php echo e(__('lang.no_data')); ?>

        </div>
      <?php endif; ?>

      <div class="col-md-12">
        <?php echo e($jobs->links()); ?>

      </div>
    </div>
  </div>
</section>
<!-- end jobs-content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>