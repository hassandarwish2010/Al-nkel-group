<?php $__env->startSection('title', __('lang.contact')); ?>
<?php $__env->startSection('description', 'Medical - Health & Medical HTML Template'); ?>
<?php $__env->startSection('keywords', 'clinic, dental, doctor, health, hospital, medical, medical theme, medicine, therapy'); ?>

<?php $__env->startSection('js'); ?>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtRmXKclfDp20TvfQnpgXSDPjut14x5wk&callback=initMap"></script>
<script>
  function initMap() {
    var lat = <?php echo e($setting_lat); ?>;
    var lon = <?php echo e($setting_lon); ?>

    var myLatLng = {lat: lat, lng: lon };

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 18,
      center: myLatLng
    });

    var marker = new google.maps.Marker({
      position: myLatLng,
      map: map,
      title: 'Medline'
    });
  };
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg1.jpg')); ?>">
  <div class="container pt-60 pb-60">
    <!-- Section Content -->
    <div class="section-content">
      <div class="row">
        <div class="col-md-12 xs-text-center">
          <h3 class="title text-white"><?php echo e(__('lang.contact')); ?></h3>
          <ol class="breadcrumb mt-10 white">
            <li><a class="text-white" href="<?php echo e(route('home', $lang)); ?>"><?php echo e(__('lang.home_page')); ?></a></li>
            <li class="active text-theme-colored"><?php echo e(__('lang.contact')); ?></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Section: Have Any Question -->
<section class="divider">
  <div class="container pt-60 pb-60">
    <div class="section-title mb-60">
      <div class="row">
        <div class="col-md-12">
          <div class="esc-heading small-border text-center">
            <h3><?php echo e(__('lang.have_questions')); ?></h3>
          </div>
        </div>
      </div>
    </div>
    <div class="section-content">
      <div class="row">
        <?php if(isset($setting->phone) && $setting->phone != null): ?>
        <div class="col-sm-12 col-md-4">
          <div class="contact-info text-center">
            <i class="fa fa-phone font-36 mb-10 text-theme-colored"></i>
            <h4><?php echo e(__('lang.call_us')); ?></h4>
            <h6 class="text-gray d-ltr"><?php echo e($setting->phone); ?></h6>
          </div>
        </div>
        <?php endif; ?>
        <?php if(isset($setting->address) && $setting->address != null): ?>
        <div class="col-sm-12 col-md-4">
          <div class="contact-info text-center">
            <i class="fa fa-map-marker font-36 mb-10 text-theme-colored"></i>
            <h4><?php echo e(__('lang.address')); ?></h4>
            <h6 class="text-gray"><?php echo e($setting->address); ?></h6>
          </div>
        </div>
        <?php endif; ?>
        <?php if(isset($setting->email) && $setting->email != null): ?>
        <div class="col-sm-12 col-md-4">
          <div class="contact-info text-center">
            <i class="fa fa-envelope font-36 mb-10 text-theme-colored"></i>
            <h4><?php echo e(__('lang.email')); ?></h4>
            <h6 class="text-gray"><?php echo e($setting->email); ?></h6>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<!-- Section Contact -->
<section id="contact" class="divider bg-lighter">
  <div class="container-fluid pt-0 pb-0">
    <div class="section-content">
      <div class="row">
        <div class="col-sm-12 col-md-6">
          <div class="contact-wrapper">
            <h3 class="line-bottom mt-0 mb-20"><?php echo e(__('lang.interested_discussing')); ?></h3>
            <!-- Contact Form -->
            <form id="contact_form_contact" name="contact_form" action="<?php echo e(route('contact.save', $lang)); ?>" method="post">
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="name"><?php echo e(__('lang.name')); ?> <small>*</small></label>
                    <input name="name" class="form-control" type="text" placeholder="<?php echo e(__('lang.name')); ?>" required="required">
                    <div id="failed_contact_page_name" class="help-block"></div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="email"><?php echo e(__('lang.email')); ?> <small>*</small></label>
                    <input name="email" class="form-control required email" type="email" placeholder="<?php echo e(__('lang.email')); ?>" required="required">
                    <div id="failed_contact_page_email" class="help-block"></div>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label for="details"><?php echo e(__('lang.details')); ?> *</label>
                <textarea name="details" class="form-control required" rows="5" placeholder="<?php echo e(__('lang.details')); ?>" required="required"></textarea>
                <div id="failed_contact_page_details" class="help-block"></div>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-dark btn-theme-colored btn-flat mr-5" data-loading-text="Please wait..."><?php echo e(__('lang.send')); ?></button>
                <button type="reset" class="btn btn-default btn-flat btn-theme-colored"><?php echo e(__('lang.reset')); ?></button>
              </div>
            </form>
          </div>
        </div>
        <div class="col-sm-12 col-md-6 bg-img-center bg-img-cover p-0">
          <div id="map" style="height:500px;width:90%;margin:50px 5%;border:1px solid #ccc;"></div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>