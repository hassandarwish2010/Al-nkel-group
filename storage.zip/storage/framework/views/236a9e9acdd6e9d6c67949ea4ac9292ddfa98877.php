<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1');
  });
</script>
<?php $__env->stopSection(); ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="title"><?php echo e(__('lang.name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('lang.name')); ?>" name="name" value="<?php if(old('name') != null): ?><?php echo e(old('name')); ?><?php elseif(isset($product)): ?><?php echo e($product->name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="category_id"><?php echo e(__('lang.category')); ?> *</label>
            <div class="input-group">
              <select class="js-example-basic-multiple-limit js-states form-control" name="category_id">
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php if(isset($product)): ?> <?php if($product->category_id == $category->id): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> <?php if(old('category_id') == $category->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($category->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('gov_id')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('gov_id')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="details"><?php echo e(__('lang.details')); ?> *</label>
                <textarea id="editor1" name="details" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.details')); ?>"><?php if(old('details') != null): ?><?php echo e(old('details')); ?><?php elseif(isset($product->details)): ?><?php echo e($product->details); ?><?php endif; ?></textarea>
                <?php if($errors->has('details')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('details')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="white-space">
      <div class="form-group">
          <label for="image"><?php echo e(__('lang.image')); ?> <?php if(isset($product)): ?> <?php else: ?> * <?php endif; ?></label>
          <div class="input-group">
              <div class="input-group-addon"><i class="ti-gallery"></i></div>
              <input type="file" class="form-control" id="image" name="image">
          </div>
          <?php if(isset($product)): ?>
            <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="thumb-image">
          <?php endif; ?>
          <div class="input-group">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="seo col-sm-12">
    <h1>SEO INFO</h1>
    <button type="button" class="btn btn-primary" onclick="loadSeoInfo();return false;" style="display: block;margin: 20px auto;">Generate SEO Info</button>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="permalink"><?php echo e(__('lang.permalink')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="permalink" placeholder="<?php echo e(__('lang.permalink')); ?>" name="permalink" value="<?php if(old('permalink') != null): ?><?php echo e(old('permalink')); ?><?php elseif(isset($product)): ?><?php echo e($product->permalink); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('permalink')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('permalink')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="keywords"><?php echo e(__('lang.keywords')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="keywords" placeholder="<?php echo e(__('lang.keywords')); ?>" name="keywords" value="<?php if(old('keywords') != null): ?><?php echo e(old('keywords')); ?><?php elseif(isset($product)): ?><?php echo e($product->keywords); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('keywords')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('keywords')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="description"><?php echo e(__('lang.description')); ?> *</label>
                <textarea name="description" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.description')); ?>"><?php if(old('description') != null): ?><?php echo e(old('description')); ?><?php elseif(isset($product->description)): ?><?php echo e($product->description); ?><?php endif; ?></textarea>
                <?php if($errors->has('description')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('description')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
