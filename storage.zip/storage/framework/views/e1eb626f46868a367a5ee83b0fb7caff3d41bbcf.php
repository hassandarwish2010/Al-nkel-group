<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('lang.name')); ?>" name="name" value="<?php if(old('name') != null): ?><?php echo e(old('name')); ?><?php elseif(isset($user)): ?><?php echo e($user->name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="email"><?php echo e(__('lang.email')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                <input type="email" class="form-control" id="email" placeholder="<?php echo e(__('lang.email')); ?>" name="email" value="<?php if(old('email') != null): ?><?php echo e(old('email')); ?><?php elseif(isset($user)): ?><?php echo e($user->email); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="password"><?php echo e(__('lang.password')); ?> <?php if(! isset($user)): ?> * <?php endif; ?></label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-ban"></i></div>
                <input type="password" class="form-control" id="password" placeholder="<?php echo e(__('lang.password')); ?>" name="password" value="<?php if(old('password') != null): ?><?php echo e(old('password')); ?><?php endif; ?>" >
            </div>
            <div class="input-group">
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
    <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.type')); ?> *</label>
            <div class="input-group" style="width: 100%">
              <select class="js-example-basic-multiple-limit js-states form-control" name="type">
                  <?php $arr=['User','Super Admin','Admin'] ?>
                  <?php for($i=0;$i<count($arr);$i++): ?>
                    <option value="<?php echo e($arr[$i]); ?>" <?php if(isset($user)): ?> <?php if($user->type == $arr[$i]): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> <?php if(old('type') == $arr[$i]): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($arr[$i]); ?></option>
                  <?php endfor; ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('type')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('type')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>


<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class=form-grop">
            <label for="address"><?php echo e(__('lang.address')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="address" placeholder="<?php echo e(__('lang.address')); ?>" name="address" value="<?php if(old('address') != null): ?><?php echo e(old('address')); ?><?php elseif(isset($user)): ?><?php echo e($user->address); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('address')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('address')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="formgroup">
            <label for="name"><?php echo e(__('lang.active')); ?> *</label>
            <div class="input-group" style="width: 100%">
              <select class="js-example-basic-multiple-limit js-states form-control" name="active">
                  <?php for($i=0;$i<2;$i++): ?>
                    <option value="<?php echo e($i); ?>" <?php if(isset($user)): ?> <?php if($user->active == $i): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> <?php if(old('active') == $i): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e(($i==0?'غير نشط':"نشط")); ?></option>
                  <?php endfor; ?>
              </select>
            </div>
            <div class="input-group">
            <?php if($errors->has('active')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('active')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-6">
    <div class="white-space">
      <div class="form-group">
          <label for="image"><?php echo e(__('lang.image')); ?> <?php if(isset($user)): ?> <?php else: ?> * <?php endif; ?></label>
          <div class="input-group">
              <div class="input-group-addon"><i class="ti-gallery"></i></div>
              <input type="file" class="form-control" id="image" name="image">
          </div>
          <?php if(isset($user->image)): ?>
            <img src="<?php echo e(asset('public/uploads/thumbs/' . $user->image)); ?>" alt="<?php echo e($user->name); ?>" class="thumb-image" style="width: 70px;height: 70px">
          <?php endif; ?>
          <div class="input-group">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
      </div>
    </div>
  </div>
 
  <div class="col col-md-6">
      <div class="white-box">
        <div class=form-grop">
            <label for="company"><?php echo e(__('lang.company')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="company" placeholder="<?php echo e(__('lang.company')); ?>" name="company" value="<?php if(old('company') != null): ?><?php echo e(old('company')); ?><?php elseif(isset($user)): ?><?php echo e($user->company); ?><?php endif; ?>" >
            </div>
            <div class="input-group">
            <?php if($errors->has('company')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('company')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="phone"><?php echo e(__('lang.phone')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="phone" placeholder="<?php echo e(__('lang.type')); ?>" name="phone" value="<?php if(old('phone') != null): ?><?php echo e(old('type')); ?><?php elseif(isset($user)): ?><?php echo e($user->phone); ?><?php endif; ?>" >
            </div>
            <div class="input-group">
            <?php if($errors->has('phone')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('phone')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.balance')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="number" step=".1" class="form-control" id="balance" placeholder="<?php echo e(__('lang.balance')); ?>" name="balance" value="<?php if(old('balance') != null): ?><?php echo e(old('balance')); ?><?php elseif(isset($user)): ?><?php echo e($user->balance); ?><?php endif; ?>" required="required" min="0">
            </div>
            <div class="input-group">
            <?php if($errors->has('balance')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('balance')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>



<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
