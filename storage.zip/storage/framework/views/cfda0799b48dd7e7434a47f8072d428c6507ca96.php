

<?php $__env->startSection('title'); ?>
  Edit <?php echo e($news->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title"><?php echo e($news->title); ?></h4>
    </div>
    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('lang.dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('news.index')); ?>"><?php echo e(__('lang.news')); ?></a></li>
        <li class="active"><?php echo e($news->title); ?></li>
      </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<div class="row">
  <div class="col-sm-12">
      <div class="white-box">
        <div class="row adminform">
          <h3 class="box-title m-b-0"><?php echo e($news->title); ?></h3>
          <form class="form-full-width" action="<?php echo e(route('news.update', $news->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

            <?php echo $__env->make('admin/news/form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </form>
        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>