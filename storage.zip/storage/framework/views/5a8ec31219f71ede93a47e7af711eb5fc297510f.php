<!-- Header -->
<header id="header" class="header">
  <div class="header-top bg-theme-colored sm-text-center"></div>
  <div class="header-middle p-0 bg-lightest xs-text-center">
    <div class="container pt-0 pb-0">
      <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-5">
          <div class="widget no-border m-0">
            <a class="menuzord-brand pull-left flip xs-pull-center mb-15" href="<?php echo e(route('home', $lang)); ?>">
              <img src="<?php echo e(asset('public/web/template/images/logo.png')); ?>" alt="Logo" style="width:50%; height:auto">
            </a>
          </div>
        </div>
        <?php if(isset($setting->phone) && $setting->phone != null): ?>
        <div class="col-xs-12 col-sm-4 col-md-4">
          <div class="widget no-border pull-right sm-pull-none sm-text-center mt-10 mb-10 m-0 pull-lang">
            <ul class="list-inline">
              <li><i class="fa fa-mobile text-theme-colored font-42 mt-5 sm-display-block"></i></li>
              <li>
                <a href="javascript:void(0);" class="font-12 text-gray text-uppercase"><?php echo e(__('lang.call_us')); ?></a>
                <h5 class="font-14 m-0 ltr-dir"><?php echo e($setting->phone); ?></h5>
              </li>
            </ul>
          </div>
        </div>
        <?php endif; ?>
        <?php if(isset($setting->email) && $setting->email != null): ?>
        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="widget no-border pull-right sm-pull-none sm-text-center mt-10 mb-10 m-0 pull-lang">
            <ul class="list-inline">
              <li><i class="fa fa-envelope text-theme-colored font-36 mt-5 sm-display-block"></i></li>
              <li>
                <a href="javascript:void(0);" class="font-12 text-gray text-uppercase"><?php echo e(__('lang.email')); ?></a>
                <h5 class="font-13 text-black m-0"><?php echo e($setting->email); ?></h5>
              </li>
            </ul>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="header-nav">
    <div class="header-nav-wrapper navbar-scrolltofixed bg-light">
      <div class="container">
        <nav id="menuzord" class="menuzord blue bg-light">
          <ul class="menuzord-menu">
            <li><a href="<?php echo e(route('home', $lang)); ?>"><?php echo e(__('lang.home')); ?></a></li>
            <?php if(count($about_pages) > 0): ?>
            <li>
              <a href="javascript:void(0);"><?php echo e(__('lang.about')); ?></a>
              <ul class="dropdown">
                <?php $__empty_1 = true; $__currentLoopData = $about_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <li><a href="<?php echo e(route('about', ['lang' => $lang, 'permalink' => $about->permalink])); ?>"><?php $about_name = $lang.'_name'?> <?php echo e($about->$about_name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
              </ul>
            </li>
            <?php endif; ?>
            <?php if(count($random_categories) > 0): ?>
            <li>
              <a href="javascript:void(0);"><?php echo e(__('lang.products')); ?></a>
              <ul class="dropdown">
                <?php $__empty_1 = true; $__currentLoopData = $random_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                  <a href="<?php echo e(route('products', ['lang' => $lang, 'category_id' => $category->id])); ?>"><?php $category_name = $lang.'_name'?> <?php echo e($category->$category_name); ?></a>
                  <ul class="dropdown">
                    <?php $__empty_2 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <li><a href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $product->permalink])); ?>"><?php $product_name = $lang.'_name'?> <?php echo e($product->$product_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <?php endif; ?>
                  </ul>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
              </ul>
            </li>
            <?php endif; ?>
            <?php if($factory_page != null): ?>
              <li><a href="<?php echo e(route('about', ['lang' => $lang, 'permalink' => $factory_page->permalink])); ?>"><?php $about_name = $lang.'_name'?> <?php echo e($factory_page->$about_name); ?></a></li>
            <?php endif; ?>
            <li><a href="<?php echo e(route('news', ['lang' => $lang])); ?>"><?php echo e(__('lang.news')); ?></a></li>
            <li><a href="<?php echo e(route('jobs', ['lang' => $lang])); ?>"><?php echo e(__('lang.jobs')); ?></a></li>
            <li><a href="<?php echo e(route('contact', ['lang' => $lang])); ?>"><?php echo e(__('lang.contact')); ?></a></li>
          </ul>
          <ul class="menuzord-menu opposite-menu">
            <li>
              <a href="<?php echo e(route('set.language', 'en')); ?>" >
                <img src='<?php echo e(asset("public/publics/images/en.png")); ?>' alt="English" title="English"/>
              </a>
            </li>
            <li>
              <a href="<?php echo e(route('set.language', 'ar')); ?>" >
                <img src='<?php echo e(asset("public/publics/images/ar.png")); ?>' alt="عربى" title="عربى"/>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</header>

<!-- Start main-content -->
<div class="main-content">
