<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdn.ckeditor.com/4.4.3/full/ckeditor.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1');
    CKEDITOR.replace('editor2');
  });
</script>
<?php $__env->stopSection(); ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="en_name"><?php echo e(__('lang.en_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="en_name" placeholder="<?php echo e(__('lang.en_name')); ?>" name="en_name" value="<?php if(old('en_name') != null): ?><?php echo e(old('en_name')); ?><?php elseif(isset($hotel)): ?><?php echo e($hotel->en_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('en_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('en_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="ar_name"><?php echo e(__('lang.ar_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="ar_name" placeholder="<?php echo e(__('lang.ar_name')); ?>" name="ar_name" value="<?php if(old('ar_name') != null): ?><?php echo e(old('ar_name')); ?><?php elseif(isset($hotel)): ?><?php echo e($hotel->ar_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('ar_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('ar_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="email"><?php echo e(__('lang.email')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="email" placeholder="<?php echo e(__('lang.email')); ?>" name="email" value="<?php if(old('email') != null): ?><?php echo e(old('email')); ?><?php elseif(isset($hotel)): ?><?php echo e($hotel->email); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>

  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="phone"><?php echo e(__('lang.phone')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                <input type="text" class="form-control" id="phone" placeholder="<?php echo e(__('lang.phone')); ?>" name="phone" value="<?php if(old('phone') != null): ?><?php echo e(old('phone')); ?><?php elseif(isset($hotel)): ?><?php echo e($hotel->phone); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('phone')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('phone')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="description_en"><?php echo e(__('lang.description_en')); ?> *</label>
                <textarea id="editor1" name="description_en" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.description_en')); ?>"><?php if(old('description_en') != null): ?><?php echo e(old('description_en')); ?><?php elseif(isset($hotel->description_en)): ?><?php echo e($hotel->description_en); ?><?php endif; ?></textarea>
                <?php if($errors->has('description_en')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('description_en')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
      <div class="white-box">
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <label for="details"><?php echo e(__('lang.description_ar')); ?> *</label>
                <textarea id="editor2" name="description_ar" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.description_ar')); ?>"><?php if(old('description_ar') != null): ?><?php echo e(old('description_ar')); ?><?php elseif(isset($hotel->description_ar)): ?><?php echo e($hotel->description_ar); ?><?php endif; ?></textarea>
                <?php if($errors->has('description_ar')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('description_ar')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="white-space">
      <div class="form-group">
          <label for="image"><?php echo e(__('lang.image')); ?> <?php if(isset($hotel)): ?> <?php else: ?> * <?php endif; ?></label>
          <div class="input-group">
              <div class="input-group-addon"><i class="ti-gallery"></i></div>
              <input type="file" class="form-control" id="image" name="image">
          </div>
          <?php if(isset($hotel)): ?>
            <img src="<?php echo e($hotel->image); ?>" alt="<?php echo e($hotel->name); ?>" class="thumb-image" style="width: 70px;height: 70px">
          <?php endif; ?>
          <div class="input-group">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
      </div>
    </div>
  </div>
</div>





<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
