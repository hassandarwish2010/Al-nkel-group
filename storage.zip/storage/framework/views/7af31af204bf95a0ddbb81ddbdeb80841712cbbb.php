

<?php $__env->startSection('title', __('lang.dashboard')); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    $.toast({
        heading: 'Welcome At Medline Dashboard',
        text: 'You can control all the website from here',
        position: 'top-right',
        loaderBg: '#FF0000',
        icon: 'info',
        hideAfter: 3500,
        stack: 6
    })
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>