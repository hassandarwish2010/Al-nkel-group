<?php
  $category_name = $lang.'_name';
  $product_name = $lang.'_name';
  $product_details = $lang.'_details';
?>

<?php $__env->startSection('title', $category->$category_name); ?>
<?php $__env->startSection('description', 'Medical - Health & Medical HTML Template'); ?>
<?php $__env->startSection('keywords', 'clinic, dental, doctor, health, hospital, medical, medical theme, medicine, therapy'); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg1.jpg')); ?>">
  <div class="container pt-60 pb-60">
    <!-- Section Content -->
    <div class="section-content">
      <div class="row">
        <div class="col-md-12 xs-text-center">
          <h3 class="title text-white"><?php echo e($category->$category_name); ?></h3>
          <ol class="breadcrumb mt-10 white">
            <li><a class="text-white" href="<?php echo e(route('home', $lang)); ?>"><?php echo e(__('lang.home_page')); ?></a></li>
            <li class="active text-theme-colored"><?php echo e($category->$category_name); ?></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="row multi-row-clearfix">
      <div class="blog-posts">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-sm-6 col-md-4">
          <article class="post clearfix mb-30 bg-lighter">
            <div class="entry-header">
              <a href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $product->permalink])); ?>" class="post-thumb thumb">
                <img src="<?php echo e($product->image); ?>" alt="" class="img-responsive img-fullwidth">
              </a>
            </div>
            <div class="entry-content p-20 pr-10">
              <div class="entry-meta media mt-0 no-bg no-border">
                <div class="media-body pl-15">
                  <div class="event-content pull-left flip">
                    <h4 class="entry-title text-theme-colored text-uppercase m-0 mt-5">
                      <a class="text-theme-colored" href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $product->permalink])); ?>"><?php echo e($product->$product_name); ?></a>
                    </h4>
                  </div>
                </div>
              </div>
              <p class="mt-10">
                <?php echo e($product->$product_details); ?>

              </p>
              <a href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $product->permalink])); ?>" class="btn-read-more"><?php echo e(__('lang.read_more')); ?></a>
              <div class="clearfix"></div>
            </div>
          </article>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo e(__('lang.no_data')); ?>

        <?php endif; ?>

        <div class="col-md-12">
          <?php echo e($products->links()); ?>

        </div>
      </div>
    </div>
  </div>
</section>
</div>
<!-- end main-content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>