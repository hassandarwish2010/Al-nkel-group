<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<div class="row">
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="en_name"><?php echo e(__('lang.en_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="en_name" placeholder="<?php echo e(__('lang.en_name')); ?>" name="en_name" value="<?php if(old('en_name') != null): ?><?php echo e(old('en_name')); ?><?php elseif(isset($airport)): ?><?php echo e($airport->en_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('en_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('en_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
  <div class="col col-md-6">
      <div class="white-box">
        <div class="form-group">
            <label for="name"><?php echo e(__('lang.ar_name')); ?> *</label>
            <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
                <input type="text" class="form-control" id="ar_name" placeholder="<?php echo e(__('lang.ar_name')); ?>" name="ar_name" value="<?php if(old('ar_name') != null): ?><?php echo e(old('ar_name')); ?><?php elseif(isset($airport)): ?><?php echo e($airport->ar_name); ?><?php endif; ?>" required="required">
            </div>
            <div class="input-group">
            <?php if($errors->has('ar_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('ar_name')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
        </div>
      </div>
  </div>
</div>

<div class="row">
  <div class="col col-md-12">
    <div class="white-box">
      <div class="form-group">
          <label style="height:16px;"></label>
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
