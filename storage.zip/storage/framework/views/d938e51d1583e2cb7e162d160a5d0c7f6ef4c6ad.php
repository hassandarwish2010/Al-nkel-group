<?php
  $job_name = $lang.'_name';
  $job_details = $lang.'_details';
?>

<?php $__env->startSection('title', $job->$job_name); ?>
<?php $__env->startSection('description', 'Medical - Health & Medical HTML Template'); ?>
<?php $__env->startSection('keywords', 'clinic, dental, doctor, health, hospital, medical, medical theme, medicine, therapy'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
  <!-- Section: inner-header -->
  <section class="inner-header divider parallax layer-overlay overlay-white-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg1.jpg')); ?>">
    <div class="container pt-60 pb-60">
      <!-- Section Content -->
      <div class="section-content">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2 class="title"><?php echo e($job->$job_name); ?></h2>
            <ol class="breadcrumb text-center text-black mt-10">
              <li><a class="text-black" href="<?php echo e(route('home', $lang)); ?>"><?php echo e(__('lang.home_page')); ?></a></li>
              <li><a class="text-black" href="<?php echo e(route('jobs', $lang)); ?>"><?php echo e(__('lang.jobs')); ?></a></li>
              <li class="active text-theme-colored"><?php echo e($job->$job_name); ?></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Section: Blog -->
  <section>
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="job-overview">
            <dl class="dl-horizontal">
              <dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
              <dd>
                <h5 class="mt-0"><?php echo e(__('lang.date_posted')); ?> :</h5>
                <p><?php echo e(__('lang.since')); ?>  <?php echo e($job->diff); ?> <?php echo e(__('lang.days_ago')); ?></p>
              </dd>
            </dl>
            <dl class="dl-horizontal">
              <dt><i class="fa fa-user text-theme-colored mt-5 font-15"></i></dt>
              <dd>
                <h5 class="mt-0"><?php echo e(__('lang.job_title')); ?> :</h5>
                <p><?php echo e($job->$job_name); ?></p>
              </dd>
            </dl>
          </div>
        </div>
        <div class="col-md-9">
          <div class="icon-box mb-0 p-0">
            <a href="#" class="icon icon-gray pull-left mb-0 mr-10">
              <i class="pe-7s-users"></i>
            </a>
            <h3 class="icon-box-title pt-15 mt-0 mb-40"><?php echo e($job->$job_name); ?></h3>
            <hr>
            <p class="text-gray">
              <?php echo $job->$job_details; ?>

            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Section: Job Apply Form -->
  <section class="divider parallax layer-overlay overlay-white-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg1.jpg')); ?>">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 col-md-offset-3 bg-lightest-transparent p-30 pt-10">
          <h3 class="text-center text-theme-colored mb-20"><?php echo e(__('lang.apply_now')); ?></h3>
          <form id="job_apply_form" name="job_apply_form" action="<?php echo e(route('job.apply', ['lang' => $lang, 'id' => $job->id])); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label><?php echo e(__('lang.name')); ?> <small>*</small></label>
                  <input name="name" type="text" placeholder="<?php echo e(__('lang.name')); ?>" required="required" class="form-control">
                  <div id="failed_job_name" class="help-block"></div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="email"><?php echo e(__('lang.email')); ?> <small>*</small></label>
                  <input name="email" class="form-control required email" type="email" placeholder="<?php echo e(__('lang.email')); ?>" required="required">
                  <div id="failed_job_email" class="help-block"></div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label><?php echo e(__('lang.details')); ?> <small>*</small></label>
              <textarea id="details" name="details" class="form-control required" rows="5" placeholder="<?php echo e(__('lang.details')); ?>"></textarea>
              <div id="failed_job_details" class="help-block"></div>
            </div>
            <div class="form-group">
              <label><?php echo e(__('lang.cv')); ?> *</label>
              <input name="cv" class="file" type="file">
              <small>Maximum upload file size: 12 MB</small>
              <div id="failed_job_cv" class="help-block"></div>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-block btn-dark btn-theme-colored btn-sm mt-20 pt-10 pb-10" data-loading-text="Please wait...">Apply Now</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>
<!-- end main-content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>