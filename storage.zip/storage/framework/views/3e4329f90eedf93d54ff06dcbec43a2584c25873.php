<!-- /.container-fluid -->
<footer class="footer text-center"> <?php echo date('Y'); ?> &copy; All right reserved <a href="http://td.com.eg" target="_blank"> Typical Design </a> </footer>
