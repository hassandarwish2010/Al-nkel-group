<?php
  $news_title = $lang.'_title';
  $news_details = $lang.'_details';
?>

<?php $__env->startSection('title', __('lang.news')); ?>
<?php $__env->startSection('description', 'Medical - Health & Medical HTML Template'); ?>
<?php $__env->startSection('keywords', 'clinic, dental, doctor, health, hospital, medical, medical theme, medicine, therapy'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.js"></script>
<script>
$(document).ready(function() {
  $(".fancybox").fancybox();
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg1.jpg')); ?>">
  <div class="container pt-60 pb-60">
    <!-- Section Content -->
    <div class="section-content">
      <div class="row">
        <div class="col-md-12 xs-text-center">
          <h3 class="title text-white"><?php echo e(__('lang.news')); ?></h3>
          <ol class="breadcrumb mt-10 white">
            <li><a class="text-white" href="<?php echo e(route('home', $lang)); ?>"><?php echo e(__('lang.home_page')); ?></a></li>
            <li class="active text-theme-colored"><?php echo e(__('lang.news')); ?></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Section: Upcoming Events -->
<section id="upcoming-events" class="divider parallax layer-overlay overlay-white-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg2.jpg')); ?>">
  <div class="container pb-50 pt-80">
    <div class="section-content">
      <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="schedule-box maxwidth500 bg-light mb-30 news-box">
            <div class="thumb">
              <img class="img-fullwidth" alt="<?php echo e($new->$news_title); ?>" src="<?php echo e($new->image); ?>">
              <div class="overlay">
                <a class="fancybox" rel="group" href="<?php echo e($new->full_image); ?>"><i class="fa fa-image mr-5"></i></a>
              </div>
            </div>
            <div class="schedule-details clearfix p-15 pt-10">
              <h5 class="font-16 title"><a href="<?php echo e(route('new', ['lang' => $lang, 'permalink' => $new->permalink])); ?>"><?php echo e($new->$news_title); ?></a></h5>
              <ul class="list-inline font-11 mb-20">
                <li><i class="fa fa-calendar mr-5"></i><?php echo e($new->created_at); ?></li>
              </ul>
              <p><?php echo e($new->$news_details); ?></p>
              <div class="mt-10">
               <a class="btn btn-dark btn-theme-colored btn-sm mt-10" href="<?php echo e(route('new', ['lang' => $lang, 'permalink' => $new->permalink])); ?>"><?php echo e(__('lang.read_more')); ?></a>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="schedule-box maxwidth500 bg-light mb-30 news-box">
            <?php echo e(__('lang.no_data')); ?>

          </div>
        </div>
        <?php endif; ?>

        <div class="col-md-12">
          <?php echo e($news->links()); ?>

        </div>
      </div>
    </div>
  </div>
</section>
</div>
<!-- end main-content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>