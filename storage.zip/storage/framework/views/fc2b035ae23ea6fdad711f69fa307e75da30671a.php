<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<div class="row">
  <div class="col col-md-6">
    <div class="white-box">
      <div class="form-group">
          <label for="image"><?php echo e(__('lang.image')); ?> <?php if(isset($agent)): ?> <?php else: ?> * <?php endif; ?></label>
          <div class="input-group">
              <div class="input-group-addon"><i class="ti-gallery"></i></div>
              <input type="file" class="form-control" id="image" name="image">
          </div>
          <?php if(isset($agent)): ?>
            <img src="<?php echo e($agent->image); ?>" alt="Agent photo" class="thumb-image">
          <?php endif; ?>
          <div class="input-group">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
      </div>
    </div>
  </div>

  <div class="col col-md-6">
    <div class="white-box">
      <div class="form-group">
        <label style="height:14px;"></label>
          <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.save')); ?></button>
      </div>
    </div>
  </div>
</div>
