<?php $__env->startSection('title', __('lang.add_new')); ?>

<?php $__env->startSection('content'); ?>
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title"><?php echo e(__('lang.add_new')); ?></h4>
    </div>
    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('lang.dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('cities.index')); ?>"><?php echo e(__('lang.cities')); ?></a></li>
        <li class="active"><?php echo e(__('lang.add_new')); ?></li>
      </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<div class="row">
  <div class="col-sm-12">
      <div class="white-box">
        <div class="row adminform">
          <h3 class="box-title m-b-0"><?php echo e(__('lang.add_new')); ?></h3>
          <form class="form-full-width" action="<?php echo e(route('cities.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('admin/cities/form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </form>
        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>