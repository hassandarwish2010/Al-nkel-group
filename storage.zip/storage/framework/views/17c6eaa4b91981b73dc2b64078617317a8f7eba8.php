
<?php echo $__env->make('layouts.dashbord.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('suberadmin.side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 


<div class="content-wrapper">
        <!-- Content Header (Page header) -->
      
        <!-- Main content -->
        <section class="content" style="margin-left: 20px;margin-right: 20px">
                <?php echo $__env->make('layouts.dashbord.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>

        </section>
            <!-- /.content -->
</div>

<?php echo $__env->make('layouts.dashbord.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>