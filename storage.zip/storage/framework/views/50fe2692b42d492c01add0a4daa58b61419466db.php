<?php $__env->startSection('title'); ?>
  From : <?php echo e($apply->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title">From : <?php echo e($apply->name); ?></h4>
    </div>
    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('lang.dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('applies.index')); ?>"><?php echo e(__('lang.applies')); ?></a></li>
        <li class="active">From : <?php echo e($apply->name); ?></li>
      </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<div class="row">
  <div class="col-12">
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>
  </div>
</div>
<section class="content">
  <div class="row">
    <div class="col-12">
      <div class="box">
        <div class="box-header">
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <h5 class="sender_name"><span class="main-color"> From : <?php echo e($apply->name); ?> </h5>
          <h5 class="sender_email"><span class="main-color"> Email </span>:  <?php echo e($apply->email); ?> </h5>
          <h5 class="job"><span class="main-color"> Job </span>:  <?php echo e($apply->job->en_name); ?> </h5>
          <a class="btn btn-primary" href="<?php echo e(asset('public/uploads/' . $apply->cv)); ?>">Download</a>
          <p class="contact_details">
            <?php echo $apply->details; ?>

          </p>
        </div>
      </div>
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>