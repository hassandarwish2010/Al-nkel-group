

<?php
  $product_name = $lang.'_name';
  $product_details = $lang.'_details';
  $category_name = $lang.'_name';
?>

<?php $__env->startSection('title', $product->$product_name); ?>

<?php $__env->startSection('description', $product->description); ?>
<?php $__env->startSection('keywords', $product->keywords); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.js"></script>
<script>
$(document).ready(function() {
  $(".fancybox").fancybox();
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
  <!-- Section: inner-header -->
  <section class="inner-header divider parallax layer-overlay overlay-white-8" data-bg-img="<?php echo e(asset('public/web/template/images/bg/bg1.jpg')); ?>">
    <div class="container pt-60 pb-60">
      <!-- Section Content -->
      <div class="section-content">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2 class="title"><?php echo e($product->$product_name); ?></h2>
            <ol class="breadcrumb text-center text-black mt-10">
              <li><a class="text-black" href="<?php echo e(route('home', $lang)); ?>"><?php echo e(__('lang.home_page')); ?></a></li>
              <li><a class="text-black" href="<?php echo e(route('products', ['lang' => $lang, 'category_id' => $product->category->id])); ?>"><?php echo e($product->category->$category_name); ?></a></li>
              <li class="active text-theme-colored"><?php echo e($product->$product_name); ?></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Section: Blog -->
  <section>
    <div class="container mt-30 mb-30 pt-30 pb-30">
      <div class="row">
        <div class="col-md-9">
          <div class="blog-posts single-post">
            <article class="post clearfix mb-0">
              <div class="entry-header">
                <div class="post-thumb thumb">
                  <a class="fancybox" rel="group" href="<?php echo e($product->full_image); ?>">
                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->$product_name); ?>" class="img-responsive img-fullwidth">
                  </a>
                </div>
              </div>
              <div class="entry-content">
                <div class="entry-meta media no-bg no-border mt-15 pb-20">
                  <div class="entry-date media-left text-center flip bg-theme-colored pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600"><?php echo e($product->day); ?></li>
                      <li class="font-12 text-white text-uppercase"><?php echo e($product->month); ?></li>
                    </ul>
                  </div>
                  <div class="media-body pl-15">
                    <div class="event-content pull-left flip">
                      <h3 class="entry-title text-theme-colored text-uppercase pt-0 mt-0"><?php echo e($product->$product_name); ?></h3>
                    </div>
                  </div>
                </div>
                <p class="mb-15">
                  <?php echo $product->$product_details; ?>

                </p>
              </div>
            </article>
          </div>
        </div>
        <div class="col-md-3">
          <div class="sidebar sidebar-right mt-sm-30">
            <div class="widget">
              <h5 class="widget-title line-bottom"><?php echo e(__('lang.categories')); ?></h5>
              <div class="categories">
                <ul class="list list-border angle-double-right">
                  <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <li><a href="<?php echo e(route('products', ['lang' => $lang, 'category_id' => $category->id])); ?>"><?php echo e($category->$category_name); ?> <span>( <?php echo e($category->products_count); ?> )</span></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <?php endif; ?>
                </ul>
              </div>
            </div>
            <div class="widget">
              <h5 class="widget-title line-bottom"><?php echo e(__('lang.related_products')); ?></h5>
              <div class="latest-posts">
                <?php $__empty_1 = true; $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="post media-post clearfix pb-0 mb-10">
                  <a class="post-thumb" href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $p->permalink])); ?>">
                    <img src="<?php echo e($p->image); ?>" alt="<?php echo e($p->$product_name); ?>" class="w-75">
                  </a>
                  <div class="post-right">
                    <h5 class="post-title mt-0"><a href="<?php echo e(route('product', ['lang' => $lang, 'permalink' => $p->permalink])); ?>"><?php echo e($p->$product_name); ?></a></h5>
                    <p><?php echo e($p->$product_details); ?></p>
                  </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <?php echo e(__('lang.no_data')); ?>

                <?php endif; ?>
              </div>
            </div>
            <div class="widget">
              <h5 class="widget-title line-bottom"><?php echo e(__('lang.gallery')); ?></h5>
              <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="col-xs-6 mb-20">
                    <a class="fancybox" rel="group" href="<?php echo e($image->full_image); ?>">
                      <img src="<?php echo e($image->image); ?>" alt="<?php echo e($product->$product_name); ?>" class="img-responsive">
                    </a>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <?php echo e(__('lang.no_data')); ?>

                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<!-- end main-content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>