<?php $__env->startSection('title'); ?>
  Message From <?php echo e($mail->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title">Message From <?php echo e($mail->name); ?></h4>
    </div>
    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('lang.dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('mails.index', $status)); ?>"><?php echo e(__('lang.mails')); ?></a></li>
        <li class="active">Message From <?php echo e($mail->name); ?></li>
      </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<div class="row">
  <div class="col-12">
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>
  </div>
</div>
<section class="content">
  <div class="row">
    <div class="col-12">
      <div class="box">
        <div class="box-header">
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <h5 class="sender_name"><span class="main-color"> Mail from </span>:  <?php echo e($mail->name); ?> </h5>
          <h5 class="sender_email"><span class="main-color"> Email </span>:  <?php echo e($mail->email); ?> </h5>

          <p class="contact_details">
            <?php echo $mail->details; ?>

          </p>
        </div>
      </div>

      <div class="box">
        <div class="box-header">
          <h3 class="box-title main-color"> Reply </h3>
        </div>
        <!-- /.box-header -->
          <form class="form-full-width" action="<?php echo e(route('mails.reply', [$mail->id])); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-md-12">
                  <div class="white-box">
                      <div class="row">
                          <div class="col-sm-12 col-xs-12">
                            <label for="details"><?php echo e(__('lang.details')); ?> *</label>
                            <textarea name="details" rows="8" class="form-control" style="resize:vertical;width:100%;" placeholder="<?php echo e(__('lang.details')); ?>"></textarea>
                            <?php if($errors->has('details')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('details')); ?></strong>
                                </span>
                            <?php endif; ?>
                          </div>

                          <div class="col col-md-12">
                            <div class="form-group" style="margin-top:30px;">
                                <button type="submit" class="btn btn-success btn-block waves-effect waves-light mt-25"><?php echo e(__('lang.send')); ?></button>
                            </div>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
        </form>
      </div>
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>